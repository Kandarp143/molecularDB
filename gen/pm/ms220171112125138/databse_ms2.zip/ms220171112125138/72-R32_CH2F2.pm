NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  1


#CH2F2
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  3.8971
epsilon   =  155.97
mass   =  52.023

SiteType   =  Dipole
NSites   =  1


#d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  2.4745
mass   =  0.0
shielding   =  0.77942

NRotAxes   =   auto
