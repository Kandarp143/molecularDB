NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


#{X}(1)
x   =  0.0
y   =  0.0
z   =  -1.0350
sigma   =  4.6727
epsilon   =  151.78
mass   =  98.691

#{X}(2)
x   =  0.0
y   =  0.0
z   =  1.0350
sigma   =  4.6727
epsilon   =  151.78
mass   =  98.691

SiteType   =  Dipole
NSites   =  1


#d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.7380
mass   =  0.0
shielding   =  0.93454

NRotAxes   =   auto
