NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  6


#CH2(1)
x   =  0
y   =  0
z   =  0
sigma   =  3.095
epsilon   =  147.03
mass   =  14.027

#CH2(2)
x   =  -2.3564648
y   =  0
z   =  0
sigma   =  3.095
epsilon   =  147.03
mass   =  14.027

#CH2(3)
x   =  -3.20735842948434
y   =  2.19747727745749
z   =  0
sigma   =  3.095
epsilon   =  147.03
mass   =  14.027

#CH2(4)
x   =  -2.35646437548297
y   =  3.43941253478034
z   =  1.81287133551242
sigma   =  3.095
epsilon   =  147.03
mass   =  14.027

#CH2(5)
x   =  4.24516858621142e-07
y   =  3.4394134114891
z   =  1.81287110519678
sigma   =  3.095
epsilon   =  147.03
mass   =  14.027

#CH2(6)
x   =  0.850893710032344
y   =  1.24193600084214
z   =  1.81287094411023
sigma   =  3.095
epsilon   =  147.03
mass   =  14.027

NRotAxes   =   auto
