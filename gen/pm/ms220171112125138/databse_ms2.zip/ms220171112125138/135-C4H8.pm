NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  4


#CH2(1)
x   =  0
y   =  0
z   =  0
sigma   =  3.537
epsilon   =  89.050
mass   =  14.027

#CH2(2)
x   =  -1.88114936521211
y   =  0
z   =  0
sigma   =  3.537
epsilon   =  89.050
mass   =  14.027

#CH2(3)
x   =  -1.81251282750396
y   =  1.87989620576911
z   =  0
sigma   =  3.537
epsilon   =  89.050
mass   =  14.027

#CH2(4)
x   =  -0.0686288761446934
y   =  1.74755070684581
z   =  0.69286633145835
sigma   =  3.537
epsilon   =  89.050
mass   =  14.027

NRotAxes   =   auto
