NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.7831
sigma   =  3.5838
epsilon   =  274.49
mass   =  64.692

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.7831
sigma   =  3.5838
epsilon   =  274.49
mass   =  64.692

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.1998
mass   =  0.0
shielding   =  0.71676

NRotAxes   =   auto