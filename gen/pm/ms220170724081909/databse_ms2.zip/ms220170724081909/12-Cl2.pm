NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# Cl (1)
x   =  0.0
y   =  0.0
z   =  -0.99095
sigma   =  3.4016
epsilon   =  160.86
mass   =  35.453

# Cl (2)
x   =  0.0
y   =  0.0
z   =  0.99095
sigma   =  3.4016
epsilon   =  160.86
mass   =  35.453

SiteType   =  Quadrupole
NSites   =  1


# q
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
quadrupole   =  4.2356
mass   =  0.0
shielding   =  0.68032

NRotAxes   =   auto