NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  5


# CH2(1)
x   =  0
y   =  0
z   =  0
sigma   =  3.235
epsilon   =  122.75
mass   =  14.027

# CH2(2)
x   =  -2.21923691404426
y   =  0
z   =  0
sigma   =  3.235
epsilon   =  122.75
mass   =  14.027

# CH2(3)
x   =  -2.69780930340047
y   =  2.16701984515761
z   =  0
sigma   =  3.235
epsilon   =  122.75
mass   =  14.027

# CH2(4)
x   =  -1.22245642053454
y   =  3.04131880113976
z   =  -1.42525894997669
sigma   =  3.235
epsilon   =  122.75
mass   =  14.027

# CH2(5)
x   =  0.525437767216078
y   =  1.63737091518038
z   =  -1.425219916263
sigma   =  3.235
epsilon   =  122.75
mass   =  14.027

NRotAxes   =   auto