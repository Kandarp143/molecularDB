NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  6


# CH2(1)
x   =  0
y   =  0
z   =  0
sigma   =  3.497
epsilon   =  87.009
mass   =  14.027

# CH2(2)
x   =  -1.9038
y   =  0
z   =  0
sigma   =  3.497
epsilon   =  87.009
mass   =  14.027

# CH2(3)
x   =  -2.59124132813369
y   =  1.77535316497135
z   =  0
sigma   =  3.497
epsilon   =  87.009
mass   =  14.027

# CH2(4)
x   =  -1.90379965703051
y   =  2.77871903018234
z   =  1.46462805154083
sigma   =  3.497
epsilon   =  87.009
mass   =  14.027

# CH2(5)
x   =  3.42969347556e-07
y   =  2.77871973847983
z   =  1.46462786546764
sigma   =  3.497
epsilon   =  87.009
mass   =  14.027

# CH2(6)
x   =  0.687441393208833
y   =  1.00336646590403
z   =  1.46462773532499
sigma   =  3.497
epsilon   =  87.009
mass   =  14.027

NRotAxes   =   auto