NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.37565
sigma   =  3.3552
epsilon   =  155.74
mass   =  23.022

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.37565
sigma   =  3.3552
epsilon   =  155.74
mass   =  23.022

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  1.6565
mass   =  0.0
shielding   =  0.67104

NRotAxes   =   auto