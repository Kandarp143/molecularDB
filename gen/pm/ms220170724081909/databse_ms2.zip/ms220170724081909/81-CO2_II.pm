NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.2088
sigma   =  2.9847
epsilon   =  133.22
mass   =  22.005

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.2088
sigma   =  2.9847
epsilon   =  133.22
mass   =  22.005

SiteType   =  Quadrupole
NSites   =  1


# q
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
quadrupole   =  3.7938
mass   =  0.0
shielding   =  0.59694

NRotAxes   =   auto