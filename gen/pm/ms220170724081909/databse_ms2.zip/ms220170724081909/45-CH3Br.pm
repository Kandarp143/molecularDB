NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


# {X}(1)
x   =  0.0
y   =  0.0
z   =  -1.3073
sigma   =  3.4557
epsilon   =  213.81
mass   =  47.470

# {X}(2)
x   =  0.0
y   =  0.0
z   =  1.3073
sigma   =  3.4557
epsilon   =  213.81
mass   =  47.470

SiteType   =  Dipole
NSites   =  1


# d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  1.8536
mass   =  0.0
shielding   =  0.69114

NRotAxes   =   auto