NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


#N(1)
x   =  0.0
y   =  0.0
z   =  -0.5232
sigma   =  3.3211
epsilon   =  34.897
mass   =  14.007

#N(2)
x   =  0.0
y   =  0.0
z   =  0.5232
sigma   =  3.3211
epsilon   =  34.897
mass   =  14.007

SiteType   =  Quadrupole
NSites   =  1


#q
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
quadrupole   =  1.4397
mass   =  0.0
shielding   =  0.66422

NRotAxes   =   auto
