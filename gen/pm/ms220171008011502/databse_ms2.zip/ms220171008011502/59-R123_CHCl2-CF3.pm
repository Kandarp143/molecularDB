NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


#{X}(1)
x   =  0.0
y   =  0.0
z   =  -2.0265
sigma   =  4.0530
epsilon   =  221.75
mass   =  76.466

#{X}(2)
x   =  0.0
y   =  0.0
z   =  2.0265
sigma   =  4.0530
epsilon   =  221.75
mass   =  76.466

SiteType   =  Dipole
NSites   =  1


#d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.7002
mass   =  0.0
shielding   =  0.8106

NRotAxes   =   auto
