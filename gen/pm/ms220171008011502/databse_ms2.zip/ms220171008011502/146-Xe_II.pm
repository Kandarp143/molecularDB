NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  1


#Xe
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  3.9450
epsilon   =  265.78
mass   =  131.293

NRotAxes   =   auto
