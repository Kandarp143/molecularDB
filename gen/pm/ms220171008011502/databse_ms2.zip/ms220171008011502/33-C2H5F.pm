NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


#{X}(1)
x   =  0.0
y   =  0.0
z   =  -1.5503
sigma   =  3.3968
epsilon   =  176.84
mass   =  24.030

#{X}(2)
x   =  0.0
y   =  0.0
z   =  1.5503
sigma   =  3.3968
epsilon   =  176.84
mass   =  24.030

SiteType   =  Dipole
NSites   =  1


#d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  2.4110
mass   =  0.0
shielding   =  0.67936

NRotAxes   =   auto
