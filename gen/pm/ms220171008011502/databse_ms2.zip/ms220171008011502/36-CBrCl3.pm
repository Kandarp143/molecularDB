NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


#{X}(1)
x   =  0.0
y   =  0.0
z   =  -1.99345
sigma   =  4.1366
epsilon   =  305.34
mass   =  99.137

#{X}(2)
x   =  0.0
y   =  0.0
z   =  1.99345
sigma   =  4.1366
epsilon   =  305.34
mass   =  99.137

SiteType   =  Dipole
NSites   =  1


#d
x   =  0.0
y   =  0.0
z   =  0.0
theta   =  0.0
phi   =  0.0
dipole   =  3.6313
mass   =  0.0
shielding   =  0.82732

NRotAxes   =   auto
