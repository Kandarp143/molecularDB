NSiteTypes  =  2


SiteType   =  LJ126
NSites   =  2


#O
x   =  0.0
y   =  0.000000
z   =  0.6721
sigma   =  3.010
epsilon   =  112.61
mass   =  15.999

#CH2
x   =  0.00
y   =  0.000000
z   =  -0.7682
sigma   =  3.422
epsilon   =  77.42
mass   =  14.027

SiteType   =  Dipole
NSites   =  1


#d
x   =  0.0
y   =  0.0
z   =  0.0480
theta   =  0.0
phi   =  0.0
dipole   =  -2.6668
mass   =  0.0
shielding   =  1.0

NRotAxes   =   auto
