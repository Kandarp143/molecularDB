NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  1


#Ne
x   =  0.0
y   =  0.0
z   =  0.0
sigma   =  2.8010
epsilon   =  33.921
mass   =  20.180

NRotAxes   =   auto
