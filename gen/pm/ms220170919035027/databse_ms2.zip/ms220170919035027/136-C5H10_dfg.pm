NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  5


#CH2(1)
x   =  0
y   =  0
z   =  0
sigma   =  3.506
epsilon   =  88.401
mass   =  14.027

#CH2(2)
x   =  -1.90445433579354
y   =  0
z   =  0
sigma   =  3.506
epsilon   =  88.401
mass   =  14.027

#CH2(3)
x   =  -2.31514467744266
y   =  1.8596436826734
z   =  0
sigma   =  3.506
epsilon   =  88.401
mass   =  14.027

#CH2(4)
x   =  -1.04800869543995
y   =  2.61055262047298
z   =  -1.2241118176952
sigma   =  3.506
epsilon   =  88.401
mass   =  14.027

#CH2(5)
x   =  0.454595773949685
y   =  1.40362694784543
z   =  -1.22407826175511
sigma   =  3.506
epsilon   =  88.401
mass   =  14.027

NRotAxes   =   auto
