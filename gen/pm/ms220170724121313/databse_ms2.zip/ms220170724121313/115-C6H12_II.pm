NSiteTypes  =  1


SiteType   =  LJ126
NSites   =  6


# CH2(2)
x   =  -0.2994
y   =  -1.5343
z   =  0.8878
sigma   =  3.49
epsilon   =  87.6
mass   =  14.027

# CH2(1)
x   =  	 0.2994
y   =  -1.5343
z   =  -0.8878
sigma   =  3.49
epsilon   =  87.6
mass   =  14.027

# CH2(3)
x   =  -0.3123
y   =  -0.0210
z   =  -1.8082
sigma   =  3.49
epsilon   =  87.6
mass   =  14.027

# CH2(5)
x   =  0.2988
y   =  1.5553
z   =  -1.0002
sigma   =  3.49
epsilon   =  87.6
mass   =  14.027

# CH2(6)
x   =  -0.3
y   =  1.5553
z   =  0.7754
sigma   =  3.49
epsilon   =  87.6
mass   =  14.027

# CH2(4)
x   =  0.3117
y   =  0.042
z   =  1.6958
sigma   =  3.49
epsilon   =  87.6
mass   =  14.027

NRotAxes   =   auto